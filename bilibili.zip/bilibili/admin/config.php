<?php
 $yzm =  array (
 'adminpass' => 'cj5277',//后台密码
 'tips' =>               //出场弹幕提示
  array (
    'time' => '6',
    'color' => '#fb7299',
    'text' => '请大家遵守弹幕礼仪',
  ),
  'ok' => '0',         //接口防窥
  );
